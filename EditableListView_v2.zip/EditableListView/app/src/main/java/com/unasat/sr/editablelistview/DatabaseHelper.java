package com.unasat.sr.editablelistview;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.Date;







    /**
     * Created by Dairfa on 2/16/2019.
     *
     */

    public class DatabaseHelper extends SQLiteOpenHelper {
        public static final String DATABASE_NAME = "mylist.db";
        public static final String TABLE_NAME = "mylist_data";
        public static final String COL1 = "ID";
        public static final String COL2 = "ITEM1";

        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "ITEM1 TEXT)";
            db.execSQL(createTable);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP IF TABLE EXISTS " + TABLE_NAME);
        }

        public boolean addData(String item1) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(COL2, item1);

            long result = db.insert(TABLE_NAME,null,contentValues);

            if(result == -1){
                return false;
            }
            else{
                return true;

            }
        }
        public Cursor getListContents(){
            SQLiteDatabase db = this.getWritableDatabase();
            Cursor data = db.rawQuery("SELECT * FROM " + TABLE_NAME,null);
            return data;
        }
    }

/*


    public class DatabaseHelper  extends SQLiteOpenHelper {
        private static final String DB_NAME = "mylist.db";
        private static final int DB_VERSION = 1;
        private static final String TABLE_WI_INFO_NAME = "weight_watcher";
        private static final String TABLE_ID = "id";
        private static final String TABLE_WI_INFO_WEIGHT = "weight";
        private static final String TABLE_WI_INFO_DATE = "date";

        private static final String CREATE_TABLE_WI_INFO = String.format(
                "create table %s(%s INT PRIMARY KEY, %s VARCHAR(255) NOT NUL , %s VARCHAR(255) NOT NULL UNIQUE);",
                TABLE_WI_INFO_NAME, TABLE_ID, TABLE_WI_INFO_WEIGHT, TABLE_WI_INFO_DATE);

        public WeightDAO(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_TABLE_WI_INFO);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        }


        public long insertOneRecord(String tableName, ContentValues contentValues) {
            SQLiteDatabase db = getWritableDatabase();
            long rowId = db.insert(tableName, null, contentValues);
            db.close();
            //return the row ID of the newly inserted row, or -1 if an error occurred
            return rowId;
        }

/*    public Cursor findRecordsRAW(String weight, String date) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        String sql = String.format("select * from %s where %s = ? OR %s = ?", TABLE_WI_INFO_NAME, TABLE_WI_INFO_WEIGHT, TABLE_WI_INFO_DATE);
        String[] whereArgs =  {weight, date};
        cursor = db.rawQuery(sql, whereArgs);
        return cursor;
    }*/
/*
        public Cursor findRecords(String weight, String date) {
            SQLiteDatabase db = getReadableDatabase();
            Cursor cursor = null;
            String whereClause = String.format("%s = ? OR %s = ?", TABLE_WI_INFO_WEIGHT, TABLE_WI_INFO_DATE);
            String[] whereArgs = {weight, date};
            cursor = db.query(TABLE_WI_INFO_NAME, null, whereClause, whereArgs ,null, null, null);
            return cursor;
        }

        public int updateRecord(ContentValues contentValues, String weight, String date) {
            SQLiteDatabase db = getWritableDatabase();
            int effectedRows = 0;
            String whereClause = String.format("%s = ? OR %s = ?", TABLE_WI_INFO_WEIGHT, TABLE_WI_INFO_DATE);
            String[] whereArgs = {weight, date};
            effectedRows = db.update(TABLE_WI_INFO_NAME, contentValues, whereClause, whereArgs);
            return effectedRows;
        }


        public int deleteRecord(String weight, String date) {
            SQLiteDatabase db = getWritableDatabase();
            int effectedRows = 0;
            String whereClause = String.format("%s = ? OR %s = ?", TABLE_WI_INFO_WEIGHT, TABLE_WI_INFO_DATE);
            String[] whereArgs = {weight, date};
            effectedRows = db.delete(TABLE_WI_INFO_NAME, whereClause, whereArgs);
            return effectedRows;
        }


    }
        */